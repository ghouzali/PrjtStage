import { createSlice } from "@reduxjs/toolkit";
import { setAuthData, getAuthData, clearAuthData } from "../../globals/auth";

export const authSlice = createSlice({
  name: "auth",
  initialState: {
    token: null,
    user: {},
    isLoggedIn: false,
  },
  reducers: {
    login: (state, action) => {
      setAuthData(action.payload);
      state.user = action.payload.user;
      state.token = action.payload.token;
      state.isLoggedIn = true;
    },
    logout: (state) => {
      clearAuthData();
      state.user = {};
      state.token = null;
      state.isLoggedIn = false;
    },
    loadAuthData: (state) => {
      const data = getAuthData();
      state.user = data.user;
      state.token = data.token;
      state.isLoggedIn = data.token !== null;
    },
  },
});

// Action creators are generated for each case reducer function
export const { login, logout, loadAuthData } = authSlice.actions;

export default authSlice.reducer;
