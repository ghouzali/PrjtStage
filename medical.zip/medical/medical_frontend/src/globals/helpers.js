import { toast } from "react-toastify";
import { playErrorSound, playNotiSound } from "./sounds";
require("datejs");

const showStatusMsg = (status = false, text = "") => {
  if (status) {
    toast.success(text);
    playNotiSound();
  } else {
    toast.error(text);
    playErrorSound();
  }
};
const showErrorMsg = (text = "") => {
  toast.error(text);
  playErrorSound();
};
const showSuccessMsg = (text = "") => {
  toast.success(text);
  playNotiSound();
};

const dt = new Date();
const diffTZ = - dt.getTimezoneOffset();
const zoneHours = Math.floor(diffTZ / 60);
const zoneMinutes = diffTZ % 60;

// --------------- time zons ---------------
const fromatToDateTime = (datetimeStr) => {
  if(datetimeStr && datetimeStr != '')
    return Date.parse(datetimeStr.split('.')[0]).add({ hours: zoneHours, minutes: zoneMinutes }).toString("ddd, MMM d, yyyy HH:mm:ss");
  else return '--';
}
const formatToDate = (datetimeStr) => {
  if(datetimeStr && datetimeStr != '')
    return Date.parse(datetimeStr.split('.')[0]).add({ hours: zoneHours, minutes: zoneMinutes }).toString("dd-MMM-yyyy");
  else return '--';
}

export { showStatusMsg, showErrorMsg, showSuccessMsg, fromatToDateTime };
