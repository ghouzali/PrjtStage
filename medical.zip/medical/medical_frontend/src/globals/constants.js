const DAY_SYMBOLS = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];

const QTY_CHOICES_ARR = [
  [1, "LOW"],
  [2, "MEDIUM"],
  [3, "HIGH"],
];
const QTY_CHOICES_OBJ = {
  1: "LOW",
  2: "MEDIUM",
  3: "HIGH",
};

export {
  DAY_SYMBOLS,
  QTY_CHOICES_ARR,
  QTY_CHOICES_OBJ,
};
