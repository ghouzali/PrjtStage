const getJsonHeaders = () => {
  const token = sessionStorage.getItem("auth_token");
  if (token) {
    return {
      "Content-Type": "application/json",
      Authorization: `Token ${token}`,
    };
  } else return { "Content-Type": "application/json" };
};
const setAuthData = (data) => {
  sessionStorage.setItem("auth_token", data.token);
  sessionStorage.setItem("auth_user", JSON.stringify(data.user));
};
const getAuthData = () => {
  const userData = sessionStorage.getItem("auth_user");
  return {
    token: sessionStorage.getItem("auth_token"),
    user: userData !== null ? JSON.parse(userData) : {},
  };
};
const clearAuthData = () => sessionStorage.clear();

export { setAuthData, getAuthData, clearAuthData, getJsonHeaders };
