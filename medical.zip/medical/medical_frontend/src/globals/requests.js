import axios from "axios";
import { getJsonHeaders } from "./auth";

const baseURL = "http://localhost:8000";

// --------------- get request ---------------

const getFromServer = async (urlPath) => {
  try {
    const res = await axios.get(`${baseURL}${urlPath}`, {
      headers: getJsonHeaders(),
    });
    if (res.status === 200 || res.status === 201) {
      return { status: true, data: res.data.data, msg: res.data.msg };
    } else if (res.status === 401 || res.status === 403) {
      return { status: false, data: {}, msg: "Authentication Error." };
    } else return { status: false, data: {}, msg: "Something went wrong." };
  } catch (error) {
    if (error.response.status === 401 || error.response.status === 403) {
      return { status: false, data: {}, msg: "Authentication Error." };
    } else return { status: false, data: {}, msg: "Something went wrong." };
  }
};

// --------------- post request ---------------
const postToServer = async (urlPath, data = {}) => {
  try {
    const res = await axios.post(`${baseURL}${urlPath}`, data, {
      headers: getJsonHeaders(),
    });
    if (res.status === 200 || res.status === 201) {
      return { status: true, data: res.data.data, msg: res.data.msg };
    } else if (res.status === 401 || res.status === 403) {
      return { status: false, data: {}, msg: "Authentication Error." };
    } else return { status: false, data: {}, msg: "Something went wrong." };
  } catch (error) {
    if (error.response.status === 401 || error.response.status === 403) {
      return { status: false, data: {}, msg: "Authentication Error." };
    } else return { status: false, data: {}, msg: "Something went wrong." };
  }
};

// --------------- put request ---------------
const putToServer = async (urlPath, data = {}) => {
  try {
    const res = await axios.put(`${baseURL}${urlPath}`, data, {
      headers: getJsonHeaders(),
    });
    if (res.status === 200 || res.status === 201) {
      return { status: true, data: res.data.data, msg: res.data.msg };
    } else if (res.status === 401 || res.status === 403) {
      return { status: false, data: {}, msg: "Authentication Error." };
    } else return { status: false, data: {}, msg: "Something went wrong." };
  } catch (error) {
    if (error.response.status === 401 || error.response.status === 403) {
      return { status: false, data: {}, msg: "Authentication Error." };
    } else return { status: false, data: {}, msg: "Something went wrong." };
  }
};

export { getFromServer, postToServer, putToServer };
