import React, { Component } from "react";
import { getFromServer, postToServer } from "../../../globals/requests";
import { showErrorMsg, showStatusMsg } from "../../../globals/helpers";
import { BoxLoader } from "../../widgets/loadings/loaders";
import { fromatToDateTime } from "../../../globals/helpers";
import { connect } from "react-redux";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faXmarkSquare,
  faCommentDots,
  faPaperPlane,
  faSpinner,
} from "@fortawesome/free-solid-svg-icons";

class ChatArea extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      sending: false,
      chats: false,
      timeSetted: false,
    };
    this.msgIn = React.createRef();
    this.chatListUI = React.createRef();
  }

  close = () => this.props.setChatAppointId(null);

  loadChats = async () => {
    this.setState({ loading: true });
    const result = await getFromServer(
      `/activities/appointment/${this.props.chatAppointId}/chats`
    );
    if (result.status) {
      this.setState({ chats: result.data });
    } else {
      showErrorMsg(result.msg);
    }
    this.setState({ loading: false }, () => {
      this.chatListUI.current.scrollTop = this.chatListUI.current.scrollHeight;
    });
  };

  getNewChats = async () => {
    const result = await getFromServer(
      `/activities/appointment/${this.props.chatAppointId}/new-chats`
    );
    if (result.status) {
      this.setState({ chats: this.state.chats.concat(result.data) }, () => {
        this.chatListUI.current.scrollTop = this.chatListUI.current.scrollHeight;
      });
      // console.log(result.data);
    } else {
      showErrorMsg(result.msg);
    }
  };

  sendMsg = async () => {
    const text = this.msgIn.current.value.trim();
    if (text !== "") {
      this.setState({ sending: true });
      const result = await postToServer(
        `/activities/appointment/${this.props.chatAppointId}/chats`,
        { msg: text }
      );
      if (result.status) {
        this.msgIn.current.value = "";
        const temp = [...this.state.chats];
        temp.push({
          id: null,
          msg: text,
          seen: false,
          created_on: result.data.created_on,
          msg_by: this.props.userId,
        });
        this.setState({ chats: temp }, () => {
          this.chatListUI.current.scrollTop = this.chatListUI.current.scrollHeight;
        });
      } else {
        showErrorMsg(result.msg);
      }
      this.setState({ sending: false });
    }
  };

  setTimer = () => {
    this.timerObj = setInterval(this.getNewChats, 10000);
  };

  componentDidMount() {
    this.loadChats();
    this.setTimer();
  }

  componentWillUnmount() {
    clearInterval(this.timerObj);
  }

  render() {
    const { loading, sending, chats } = this.state;

    return (
      <div className="popup show lg">
        <div className="overlay"></div>
        <div className="content">
          <h2 style={{ paddingTop: "-5px", display: "inline-block" }}>
            <FontAwesomeIcon icon={faCommentDots} /> Chat User
          </h2>
          <FontAwesomeIcon
            id="close-btn"
            icon={faXmarkSquare}
            onClick={this.close}
            color="green"
          />
          <div className="divider"></div>
          {loading ? (
            <BoxLoader height="250px" />
          ) : (
            <div className="chat-area">
              <div className="chat-list" ref={this.chatListUI}>
                {chats.map((chat) => (
                  <div
                    className={`chat ${
                      chat.msg_by === this.props.userId && "me"
                    }`}
                  >
                    <p>{chat.msg}</p>
                    <small>{fromatToDateTime(chat.created_on)}</small>
                  </div>
                ))}
              </div>
              <div className="chat-box">
                <textarea
                  ref={this.msgIn}
                  rows="2"
                  disabled={sending}
                ></textarea>
                {sending ? (
                  <button disabled>
                    <FontAwesomeIcon icon={faSpinner} pulse />
                  </button>
                ) : (
                  <button onClick={this.sendMsg}>
                    <FontAwesomeIcon icon={faPaperPlane} />
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  userId: state.auth.user.id,
});

export default connect(mapStateToProps)(ChatArea);
