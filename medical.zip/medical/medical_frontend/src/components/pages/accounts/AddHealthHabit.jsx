import React, { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { QTY_CHOICES_ARR } from "../../../globals/constants";
import { BtnWaiting } from "../../widgets/loadings/Buttons";
import { postToServer } from "../../../globals/requests";
import { showStatusMsg } from "../../../globals/helpers";

const AddHealthHabit = () => {
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const refs = {
    date: useRef(null),
  
    exercise: useRef(null),
    food_consumption: useRef(null),
    water_consumption: useRef(null),
    good_sleep: useRef(null),
    smoke: useRef(null),
    stress: useRef(null),
    screen_time: useRef(null),
  };

  const saveData = async (e) => {
    e.preventDefault();
    setSaving(true);
    const data = {};
    Object.entries(refs).forEach(function ([key, refObj]) {
      console.log(key);
      data[key] = refObj.current.value;
    });
    const result = await postToServer(`/accounts/my-health-habits`, data);
    showStatusMsg(result.status, result.msg);
    if (result.status) navigate("/accounts/my-health-habits");
    setSaving(false);
  };

  return (
    <main>
      <div className="cont">
        <h2 className="title">ADD/INPUT HEALTH HABITS</h2>
        <form className="form" onSubmit={saveData}>
          <p className="full">
            <label htmlFor="date">Record Date</label>
            <input type="date" id="date" ref={refs.date} required />
          </p>
          <p>
            <label htmlFor="exercise">Exercise</label>
            <select id="exercise" ref={refs.exercise} required>
              <option value="">Select a option</option>
              <option value="1">YES</option>
              <option value="0">NO</option>
            </select>
          </p>
          <p>
            <label htmlFor="food_consumption">Food Consumption</label>
            <select id="food_consumption" ref={refs.food_consumption} required>
              <option value="">Select a option</option>
              {QTY_CHOICES_ARR.map((row) => (
                <option value={row[0]}>{row[1]}</option>
              ))}
            </select>
          </p>
          <p>
            <label htmlFor="water_consumption">Water Consumption</label>
            <select
              id="water_consumption"
              ref={refs.water_consumption}
              required
            >
              <option value="">Select a option</option>
              {QTY_CHOICES_ARR.map((row) => (
                <option value={row[0]}>{row[1]}</option>
              ))}
            </select>
          </p>
          <p>
            <label htmlFor="good_sleep">Good Sleep</label>
            <select id="good_sleep" ref={refs.good_sleep} required>
              <option value="">Select a option</option>
              <option value="1">YES</option>
              <option value="0">NO</option>
            </select>
          </p>
          <p>
            <label htmlFor="smoke">Smoked</label>
            <select id="smoke" ref={refs.smoke} required>
              <option value="">Select a option</option>
              <option value="1">YES</option>
              <option value="0">NO</option>
            </select>
          </p>
          <p>
            <label htmlFor="stress">stress</label>
            <select id="stress" ref={refs.stress} required>
              <option value="">Select a option</option>
              {QTY_CHOICES_ARR.map((row) => (
                <option value={row[0]}>{row[1]}</option>
              ))}
            </select>
          </p>
          <p>
            <label htmlFor="screen_time">Screen Time</label>
            <select id="screen_time" ref={refs.screen_time} required>
              <option value="">Select a option</option>
              {QTY_CHOICES_ARR.map((row) => (
                <option value={row[0]}>{row[1]}</option>
              ))}
            </select>
          </p>
          <div className="btn-gp">
            {saving ? (
              <BtnWaiting />
            ) : (
              <button className="btn">Save Activities</button>
            )}
          </div>
        </form>
      </div>
    </main>
  );
};

export default AddHealthHabit;
