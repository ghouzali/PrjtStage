import React, { useRef, useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { startLoading, stopLoading } from "../../../app/slices/uiSlice";
import { BtnWaiting } from "../../widgets/loadings/Buttons";
import { putToServer, getFromServer } from "../../../globals/requests";
import { showStatusMsg, showErrorMsg } from "../../../globals/helpers";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faStethoscope,
  faCrown,
  faHospitalUser,
} from "@fortawesome/free-solid-svg-icons";

const ROLES = {
  1: (
    <span>
      <FontAwesomeIcon icon={faCrown} /> ADMINISTRATOR
    </span>
  ),
  2: (
    <span>
      <FontAwesomeIcon icon={faStethoscope} /> DOCTOR
    </span>
  ),
  3: (
    <span>
      <FontAwesomeIcon icon={faHospitalUser} /> PATIENT
    </span>
  ),
};

const MyProfile = () => {
  const dispatch = useDispatch();
  const username = useRef(null);
  const about = useRef(null);
  const [role, setRole] = useState("");
  const [saving, setSaving] = useState(false);

  const refs = {
    first_name: useRef(null),
    last_name: useRef(null),
    email: useRef(null),
  };

  const loadProfileInfo = async () => {
    dispatch(startLoading());
    const result = await getFromServer(`/accounts/my-profile`);
    if (result.status) {
      Object.entries(result.data.user).forEach(function ([key, value]) {
        if (refs[key]) refs[key].current.value = value;
      });
      username.current.value = result.data.user.username;
      about.current.value = result.data.profile.about;
      setRole(ROLES[result.data.user.role]);
    } else showErrorMsg(result.msg);
    dispatch(stopLoading());
  };
  const saveProfile = async (e) => {
    e.preventDefault();
    setSaving(true);
    const data = { user: {}, profile: {} };
    Object.entries(refs).forEach(function ([key, refObj]) {
      data.user[key] = refObj.current.value;
    });
    data.profile.about = about.current.value;
    const result = await putToServer(`/accounts/my-profile`, data);
    showStatusMsg(result.status, result.msg);
    setSaving(false);
  };

  useEffect(() => {
    loadProfileInfo();
  }, []);

  return (
    <main>
      <div className="cont">
        <h2 className="title">PROFILE INFORMATION</h2>
        <h3 style={{ marginBottom: "10px" }}>Account Role: {role}</h3>
        <form className="form" onSubmit={saveProfile}>
          <p>
            <label htmlFor="first_name">First Name</label>
            <input type="text" id="first_name" ref={refs.first_name} />
          </p>
          <p>
            <label htmlFor="last_name">Last Name</label>
            <input type="text" id="last_name" ref={refs.last_name} />
          </p>
          <p>
            <label htmlFor="username">Username</label>
            <input type="text" id="username" ref={username} disabled />
          </p>
          <p>
            <label htmlFor="email">Email</label>
            <input type="text" id="email" ref={refs.email} required />
          </p>
          <p className="full">
            <label htmlFor="about">About</label>
            <textarea id="about" ref={about} rows="5"></textarea>
          </p>
          <div className="btn-gp">
            {saving ? (
              <BtnWaiting />
            ) : (
              <button className="btn">Save Profile</button>
            )}
          </div>
        </form>
      </div>
    </main>
  );
};

export default MyProfile;
