import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { BoxLoader } from "../../widgets/loadings/loaders";
import { getFromServer } from "../../../globals/requests";
import { showErrorMsg } from "../../../globals/helpers";
import { QTY_CHOICES_OBJ } from "../../../globals/constants";

const MyHealthHabits = () => {
  const [habitActivities, setHabitActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadMyHabitActivitie = async () => {
    setLoading(true);
    const result = await getFromServer("/accounts/my-health-habits");
    if (result.status) {
      setHabitActivities(result.data);
    } else showErrorMsg(result.msg);
    setLoading(false);
  };

  useEffect(() => {
    loadMyHabitActivitie();
  }, []);

  return (
    <main>
      <div className="cont">
        <Link
          to="/accounts/add-health-habits"
          className="btn"
          style={{ float: "right" }}
        >
          Add Activity
        </Link>
        <h2 className="title">MY HEALTH ACTIVITIES</h2>
        {loading ? (
          <BoxLoader height="150px" />
        ) : habitActivities.length > 0 ? (
          <div className="tbl-box">
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Record&nbsp;Date</th>
                  <th>Exercise</th>
                  <th>Food Consumed</th>
                  <th>Water Consumed</th>
                  <th>Good Sleep</th>
                  <th>Stress</th>
                  <th>Screen Time</th>
                  <th>AI-driven Recommendations</th>
                </tr>
              </thead>
              <tbody>
                {habitActivities.map((activity, i) => (
                  <tr>
                    <th>{i + 1}</th>
                    <td>{activity.date}</td>
                    <td>{activity.exercise ? "YES" : "NO"}</td>
                    <td>{QTY_CHOICES_OBJ[activity.food_consumption]}</td>
                    <td>{QTY_CHOICES_OBJ[activity.water_consumption]}</td>
                    <td>{activity.good_sleep ? "YES" : "NO"}</td>
                    <td>{QTY_CHOICES_OBJ[activity.stress]}</td>
                    <td>{QTY_CHOICES_OBJ[activity.screen_time]}</td>
                    <td><b>{activity.recommendations}</b></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p style={{ textAlign: "center" }}>No Record found</p>
        )}
      </div>
    </main>
  );
};

export default MyHealthHabits;
