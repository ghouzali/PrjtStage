import React, { useRef, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import maleDoctor from "../../../assets/images/male-doctor.png";
import femaleDoctor from "../../../assets/images/female-doctor.png";

import { getFromServer } from "../../../globals/requests";
import { showErrorMsg } from "../../../globals/helpers";
import { DAY_SYMBOLS } from "../../../globals/constants";
import { BoxLoader } from "../../widgets/loadings/loaders";
import Popup from "../../widgets/Popup";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faMagnifyingGlass,
  faSpinner,
  faStar,
  faFilter,
  faSort,
} from "@fortawesome/free-solid-svg-icons";

const rowStyle = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
};

const DoctorList = () => {
  const [showFilters, setShowFilters] = useState(false);
  const [showSortings, setShowSortings] = useState(false);
  const [docLoading, setDocLoading] = useState(false);
  const [doctors, setDoctors] = useState([]);
  const [filterCount, setFilterCount] = useState([]);
  const [filters, setFilters] = useState("");
  const [sorting, setSorting] = useState("");
  const search = useRef(null);
  const order = {
    rating_asc: useRef(null),
    rating_desc: useRef(null),
    name_asc: useRef(null),
    name_desc: useRef(null),
  };

  const specialties = {
    1: useRef(null),
    2: useRef(null),
    3: useRef(null),
    4: useRef(null),
    5: useRef(null),
    6: useRef(null),
  };
  const gender = {
    1: useRef(null),
    2: useRef(null),
    3: useRef(null),
  };
  const languages = {
    1: useRef(null),
    2: useRef(null),
    3: useRef(null),
  };
  const kindOfDiseases = {
    1: useRef(null),
    2: useRef(null),
    3: useRef(null),
    4: useRef(null),
    5: useRef(null),
    6: useRef(null),
    7: useRef(null),
    8: useRef(null),
  };
  const stars = {
    1: useRef(null),
    2: useRef(null),
    3: useRef(null),
    4: useRef(null),
    5: useRef(null),
  };
  const acceptInsurances = useRef(null);
  const updateFilters = (byUser = false) => {
    let filterStr = "";
    let count = 0;
    const acceptInsurancesState = acceptInsurances.current.checked ? 1 : 0;
    if (acceptInsurancesState) count++;

    filterStr += `accept_insurances=${acceptInsurancesState}`;

    let temp = [];
    Object.entries(specialties).forEach(([key, refObj]) => {
      if (refObj.current.checked) temp.push(key);
    });
    filterStr += `&specialties=${temp.join(",")}`;
    count += temp.length;

    temp = [];
    Object.entries(gender).forEach(([key, refObj]) => {
      if (refObj.current.checked) temp.push(key);
    });
    filterStr += `&gender=${temp.join(",")}`;
    count += temp.length;

    temp = [];
    Object.entries(languages).forEach(([key, refObj]) => {
      if (refObj.current.checked) temp.push(key);
    });
    filterStr += `&languages=${temp.join(",")}`;
    count += temp.length;

    temp = [];
    Object.entries(kindOfDiseases).forEach(([key, refObj]) => {
      if (refObj.current.checked) temp.push(key);
    });
    filterStr += `&kind_of_diseases=${temp.join(",")}`;
    count += temp.length;

    temp = [];
    Object.entries(stars).forEach(([key, refObj]) => {
      if (refObj.current.checked) temp.push(key);
    });
    filterStr += `&stars=${temp.join(",")}`;
    count += temp.length;

    setFilterCount(count);
    const reload = byUser && filters != filterStr;
    setFilters(filterStr);
    if (reload) loadDoctors(filterStr, sorting);
  };
  const closeFilters = () => {
    setShowFilters(false);
    updateFilters(true);
  };

  const updateSorting = (byUser = false) => {
    let sortingStr = "sorting=";
    if(order.rating_asc.current.checked) sortingStr += 'stars ASC NULLS FIRST';
    else if(order.rating_desc.current.checked) sortingStr += 'stars DESC NULLS LAST';
    else if(order.name_asc.current.checked) sortingStr += 'name ASC';
    else if(order.name_desc.current.checked) sortingStr += 'name DESC';
    const reload = byUser && sorting != sortingStr;
    setSorting(sortingStr)
    if (reload) loadDoctors(filters, sortingStr);
  }

  const closeSortings = () => {
    setShowSortings(false);
    updateSorting(true)
  };

  const loadDoctors = async (filterStr, sortingStr) => {
    setDocLoading(true);
    setDoctors([]);
    const params = `search=${search.current.value.trim()}`;
    const result = await getFromServer(`/doctor-list?${params}&${filterStr}&${sortingStr}`);
    if (result.status) {
      setDoctors(result.data);
    } else showErrorMsg(result.msg);
    setDocLoading(false);
  };

  useEffect(() => {
    updateFilters();
    updateSorting();
  }, []);
  return (
    <main>
      <div className="cont">
        <h2 className="title">DOCTOR LIST</h2>
        <p className="doc-search">
          <input
            type="search"
            ref={search}
            placeholder="Search a doctor with name or username."
          />
          {docLoading ? (
            <button disabled>
              <FontAwesomeIcon icon={faSpinner} pulse />
            </button>
          ) : (
            <button onClick={() => loadDoctors(filters, sorting)}>
              <FontAwesomeIcon icon={faMagnifyingGlass} />
            </button>
          )}
        </p>
        <br />
        <div>
          <button
            className="btn"
            onClick={() => setShowFilters(true)}
            disabled={docLoading}
          >
            <FontAwesomeIcon icon={faFilter} /> Filters
            {filterCount > 0 && ` - ${filterCount} Applied`}
          </button>
          &nbsp;&nbsp;
          <button className="btn" onClick={() => setShowSortings(true)}>
            <FontAwesomeIcon icon={faSort} /> Sorting
          </button>
        </div>
        <br />
        {docLoading ? (
          <BoxLoader height="150px" />
        ) : doctors.length > 0 ? (
          <div className="doctors">
            {doctors.map((doctor) => (
              <div className="doctor" key={doctor.id}>
                <div className="info">
                  <figure>
                    <img
                      src={doctor.gender === 2 ? femaleDoctor : maleDoctor}
                      alt="Doctor Avatar"
                    />
                  </figure>
                  <div>
                    <h3>
                      {doctor.first_name} {doctor.last_name}
                    </h3>
                    <h4>@{doctor.username}</h4>
                    <h4>Daily Availability</h4>
                    <p>
                      {doctor.avail_st_time} - {doctor.avail_end_time}
                    </p>
                  </div>
                </div>
                {doctor.stars ? (
                  <h4 style={rowStyle}>
                    <span>Days Availability</span>
                    &nbsp;
                    <span>
                      <FontAwesomeIcon icon={faStar} color="orange" />{" "}
                      {doctor.stars}
                    </span>
                  </h4>
                ) : (
                  <h4>Days Availability</h4>
                )}
                <div className="avail-days">
                  {doctor.avail_days.map((day, i) =>
                    day ? <p>{DAY_SYMBOLS[i]}</p> : <></>
                  )}
                </div>
                <h5 style={rowStyle}>
                  <b>{doctor.specialty}</b>
                  &nbsp;
                  <b>{doctor.kind_of_diseases}</b>
                </h5>
                <div className="actions">
                  <Link to={`/doctor/${doctor.username}`}>View More</Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ textAlign: "center" }}>No Doctors.</p>
        )}
      </div>
      <Popup lg show={showFilters} title="Filters" setShow={closeFilters}>
        <div className="doc-filters">
          <div>
            <h3>Specialties</h3>
            <p>
              <input type="checkbox" ref={specialties[1]} id="specialty1" />
              <label htmlFor="specialty1">Cardiologist</label>
            </p>
            <p>
              <input type="checkbox" ref={specialties[2]} id="specialty2" />
              <label htmlFor="specialty2">Dermatologist</label>
            </p>
            <p>
              <input type="checkbox" ref={specialties[3]} id="specialty3" />
              <label htmlFor="specialty3">Neurologist</label>
            </p>
            <p>
              <input type="checkbox" ref={specialties[4]} id="specialty4" />
              <label htmlFor="specialty4">Pediatrician</label>
            </p>
            <p>
              <input type="checkbox" ref={specialties[5]} id="specialty5" />
              <label htmlFor="specialty5">Ophthalmologist</label>
            </p>
            <p>
              <input type="checkbox" ref={specialties[6]} id="specialty6" />
              <label htmlFor="specialty6">Gastroenterologist</label>
            </p>
          </div>
          <div>
            <h3>Doctor Gender</h3>
            <p>
              <input type="checkbox" id="gender1" ref={gender[1]} />
              <label htmlFor="gender1">Male</label>
            </p>
            <p>
              <input type="checkbox" id="gender2" ref={gender[2]} />
              <label htmlFor="gender2">Female</label>
            </p>
            <p>
              <input type="checkbox" id="gender3" ref={gender[3]} />
              <label htmlFor="gender3">Others</label>
            </p>
          </div>
          <div>
            <h3>Spoken Language</h3>
            <p>
              <input type="checkbox" id="lang1" ref={languages[1]} />
              <label htmlFor="lang1">English</label>
            </p>
            <p>
              <input type="checkbox" id="lang2" ref={languages[2]} />
              <label htmlFor="lang2">French</label>
            </p>
            <p>
              <input type="checkbox" id="lang3" ref={languages[3]} />
              <label htmlFor="lang3">Breton</label>
            </p>
          </div>
          <div>
            <h3>Kind of Diseases</h3>
            <p>
              <input type="checkbox" id="kind1" ref={kindOfDiseases[1]} />
              <label htmlFor="kind1">Infectious Diseases</label>
            </p>
            <p>
              <input type="checkbox" id="kind2" ref={kindOfDiseases[2]} />
              <label htmlFor="kind2">Chronic Diseases</label>
            </p>
            <p>
              <input type="checkbox" id="kind3" ref={kindOfDiseases[3]} />
              <label htmlFor="kind3">Respiratory Diseases</label>
            </p>
            <p>
              <input type="checkbox" id="kind4" ref={kindOfDiseases[4]} />
              <label htmlFor="kind4">Cardiovascular Diseases</label>
            </p>
            <p>
              <input type="checkbox" id="kind5" ref={kindOfDiseases[5]} />
              <label htmlFor="kind5">Mental Health Disorders</label>
            </p>
            <p>
              <input type="checkbox" id="kind6" ref={kindOfDiseases[6]} />
              <label htmlFor="kind6">Inflammatory Conditions</label>
            </p>
            <p>
              <input type="checkbox" id="kind7" ref={kindOfDiseases[7]} />
              <label htmlFor="kind7">Infectious Diseases</label>
            </p>
            <p>
              <input type="checkbox" id="kind8" ref={kindOfDiseases[8]} />
              <label htmlFor="kind8">Cancer</label>
            </p>
          </div>
          <div>
            <h3>Rating(Stars)</h3>
            <p>
              <input type="checkbox" ref={stars[5]} id="stars5" />
              <label htmlFor="stars5">
                <FontAwesomeIcon icon={faStar} color="orange" />
                <FontAwesomeIcon icon={faStar} color="orange" />
                <FontAwesomeIcon icon={faStar} color="orange" />
                <FontAwesomeIcon icon={faStar} color="orange" />
                <FontAwesomeIcon icon={faStar} color="orange" />
              </label>
            </p>
            <p>
              <input type="checkbox" ref={stars[4]} id="stars4" />
              <label htmlFor="stars4">
                <FontAwesomeIcon icon={faStar} color="orange" />
                <FontAwesomeIcon icon={faStar} color="orange" />
                <FontAwesomeIcon icon={faStar} color="orange" />
                <FontAwesomeIcon icon={faStar} color="orange" />
              </label>
            </p>
            <p>
              <input type="checkbox" ref={stars[3]} id="stars3" />
              <label htmlFor="stars3">
                <FontAwesomeIcon icon={faStar} color="orange" />
                <FontAwesomeIcon icon={faStar} color="orange" />
                <FontAwesomeIcon icon={faStar} color="orange" />
              </label>
            </p>
            <p>
              <input type="checkbox" ref={stars[2]} id="stars2" />
              <label htmlFor="stars2">
                <FontAwesomeIcon icon={faStar} color="orange" />
                <FontAwesomeIcon icon={faStar} color="orange" />
              </label>
            </p>
            <p>
              <input type="checkbox" ref={stars[1]} id="stars1" />
              <label htmlFor="stars1">
                <FontAwesomeIcon icon={faStar} color="orange" />
              </label>
            </p>
          </div>
          <div>
            <h3>Others</h3>
            <p>
              <input
                type="checkbox"
                id="accept_insurances"
                ref={acceptInsurances}
              />
              <label htmlFor="accept_insurances">Accept Insurances</label>
            </p>
          </div>
        </div>
      </Popup>
      <Popup show={showSortings} title="Sorting" setShow={closeSortings}>
        <div className="doc-filters">
          <div>
            <h3>Rating(Stars)</h3>
            <p>
              <input
                type="radio"
                id="rating_asc"
                name="order"
                ref={order.rating_asc}
              />
              <label htmlFor="rating_asc">Rating (Low to High)</label>
            </p>
            <p>
              <input
                type="radio"
                id="rating_desc"
                name="order"
                ref={order.rating_desc}
              />
              <label htmlFor="rating_desc">Rating (High to Low)</label>
            </p>
          </div>
          <div>
            <h3>Doctor Name</h3>
            <p>
              <input
                type="radio"
                id="name_asc"
                name="order"
                ref={order.name_asc}
              />
              <label htmlFor="name_asc">Name (Alphabetical ASC)</label>
            </p>
            <p>
              <input
                type="radio"
                id="name_desc"
                name="order"
                ref={order.name_desc}
              />
              <label htmlFor="name_desc">Name (Alphabetical DESC)</label>
            </p>
          </div>
        </div>
      </Popup>
    </main>
  );
};

export default DoctorList;
