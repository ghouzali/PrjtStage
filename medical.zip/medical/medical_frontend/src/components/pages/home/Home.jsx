import React from "react";
import { Link } from "react-router-dom";
import doctorPic from "../../../assets/images/doctor-pic.jpg";
// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faStethoscope,
  faPhone,
  faEnvelope,
} from "@fortawesome/free-solid-svg-icons";
import {
  faFacebookF,
  faWhatsapp,
  faInstagram,
  faTwitter,
} from "@fortawesome/free-brands-svg-icons";

const Home = () => {
  return (
    <>
      <div className="banner">
        <h1>Best Medical Faculty In The Globe</h1>
      </div>
      <main>
        <div className="why-choose-us">
          <div>
            <h1>Why Choose Us?</h1>
            <div>
              <h2>Expertise & Excellence</h2>
              <p>
                Our team of board-certified physicians and dedicated healthcare
                professionals is committed to delivering the highest standard of
                care. We bring expertise and excellence to every patient
                interaction.
              </p>
            </div>
            <div>
              <h2>Comprehensive Services</h2>
              <p>
                From routine medical care to specialized treatments and
                emergency services, DigiMed is your trusted healthcare partner.
                Explore our range of services designed to meet your unique
                needs.
              </p>
            </div>
            <div>
              <h2>Patient-Centered Care</h2>
              <p>
                Your well-being is our priority. Our patient-centered approach
                ensures you receive personalized care, and our team collaborates
                with you for the best possible outcomes.
              </p>
            </div>
          </div>
          <figure>
            <img src={doctorPic} alt="Doctor" />
          </figure>
        </div>
      </main>
      <footer>
        <div className="footer-top lg-line-ht container">
          <div>
            <div className="logo">
              <FontAwesomeIcon icon={faStethoscope} />
              DigiMed
            </div>
            <p>
              At DigiMed, we uphold the highest standards of quality and safety.
              Our commitment to excellence has earned us recognition within the
              medical community.
            </p>
          </div>
          <div>
            <h2 className="title2">Social Media</h2>
            <div className="links-list">
              <Link to="#">
                <FontAwesomeIcon icon={faFacebookF} />{" "}
                Facebook
              </Link>
              <Link to="#">
                <FontAwesomeIcon icon={faInstagram} />{" "}
                Instagram
              </Link>
              <Link to="#">
                <FontAwesomeIcon icon={faWhatsapp} />{" "}
                WhatsApp
              </Link>
              <Link to="#">
                <FontAwesomeIcon icon={faTwitter} />{" "}
                Twitter
              </Link>
            </div>
          </div>
          <div>
            <h2 className="title2">Useful Links</h2>
            <div className="links-list">
              <Link to="#">About Us</Link>
              <Link to="#">Contact Us</Link>
              <Link to="#">Terms & Conditions</Link>
              <Link to="#">Privacy Policy</Link>
            </div>
          </div>
          <div>
            <h2 className="title2">Contact</h2>
            <p>
              Eiffel Tower,
              <br />
              Champ de Mars, 5 Avenue Anatole France, 75007 Paris, France
            </p>
            <br />
            <div className="links-list">
              <Link to="#">
                <FontAwesomeIcon icon={faPhone} />{" "}
                +1 (438) 835-9735
              </Link>
              <Link to="#">
                <FontAwesomeIcon icon={faEnvelope} />{" "}
                admin@gmail.com
              </Link>
            </div>
          </div>
        </div>
        <div style={{ borderBottom: "2px solid #eee" }}></div>
        <div className="footer-bottom container">
          <p>
            Copyright &#169;2023 <b>DigiMed PRIVATE LIMITED</b> all rights are
            reserved.
          </p>
        </div>
      </footer>
    </>
  );
};

export default Home;
