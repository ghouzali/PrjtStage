import React, { useRef, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { startLoading, stopLoading } from "../../../app/slices/uiSlice";
import { getFromServer, postToServer } from "../../../globals/requests";
import { showSuccessMsg, showErrorMsg } from "../../../globals/helpers";
import { useParams } from "react-router-dom";
import maleDoctor from "../../../assets/images/male-doctor.png";
import femaleDoctor from "../../../assets/images/female-doctor.png";
import male from "../../../assets/images/male.png";
import female from "../../../assets/images/female.png";
import { DAY_SYMBOLS } from "../../../globals/constants";
import { BoxLoader } from "../../widgets/loadings/loaders";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCircleChevronDown,
  faCircleChevronRight,
  faStar,
} from "@fortawesome/free-solid-svg-icons";

const DoctorDetailsPage = () => {
  const loggedInUsername = useSelector((state) => state.auth.user.username);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(true);
  const { username } = useParams();
  const [docUser, setDocUser] = useState({});
  const [docProfile, setDocProfile] = useState({});
  const [timings, setTimings] = useState([]);
  const [appointmentFeedbacks, setAppointmentFeedbacks] = useState([]);

  const loadAppointmentDetails = async () => {
    const url = `/activities/doctor/${username}`;
    const result = await getFromServer(url);
    if (result.status) {
      setDocUser(result.data.user);
      setDocProfile(result.data.profile);
      setTimings(result.data.availability);
      const appointment_feedbacks = result.data.appointment_feedbacks;
      appointment_feedbacks.forEach((feedback) => {
        feedback.uiStars = [false, false, false, false, false];
        for (let i = 0; i < feedback.stars; i++) feedback.uiStars[i] = true;
      });
      setAppointmentFeedbacks(appointment_feedbacks);
    } else showErrorMsg(result.msg);
    setLoading(false);
  };
  const hideShowSlots = (i) => {
    const temp = [...timings];
    temp[i].expanded = !temp[i].expanded;
    setTimings(temp);
  };
  const bookSlot = async (i, j) => {
    dispatch(startLoading());
    const timeArr = timings[i].slots[j][0].split("-");
    const data = {
      date: timings[i].date,
      st_time: timeArr[0].trim(),
      end_time: timeArr[1].trim(),
    };
    const url = `/activities/doctor/${docUser.id}/book-appointment`;
    const result = await postToServer(url, data);
    if (result.status) {
      if (result.data.booked) {
        showSuccessMsg(result.msg);
        navigate("/accounts/my-appointments");
      } else showErrorMsg(result.msg);
    } else showErrorMsg(result.msg);
    dispatch(stopLoading());
  };

  useEffect(() => {
    loadAppointmentDetails();
  }, []);

  return (
    <main>
      <div className="cont">
        <h2 className="title">DOCTOR DETAIL</h2>
        {loading ? (
          <BoxLoader height="150px" />
        ) : (
          <div className="doc-detail">
            <figure>
              <img
                src={docUser.gender === 2 ? femaleDoctor : maleDoctor}
                alt="Doctor Avatar"
              />
            </figure>
            <div>
              <h3>
                {docUser.first_name} {docUser.last_name}
              </h3>
              <h4>@{docUser.username}</h4>
              <h3>Daily Availability</h3>
              <p>
                {docProfile.avail_st_time} - {docProfile.avail_end_time}
              </p>
              <h3>Days Availability</h3>
              <div className="avail-days">
                {docProfile.avail_days.map((day, i) =>
                  day ? <p>{DAY_SYMBOLS[i]}</p> : <></>
                )}
              </div>
            </div>
          </div>
        )}
        {username !== loggedInUsername && (
          <>
            <h2 className="title">BOOK APPOINTMENT</h2>
            {loading ? (
              <BoxLoader height="150px" />
            ) : (
              timings.map((timing, i) => (
                <div className="appoint-day">
                  <div>
                    <button className="i-btn" onClick={() => hideShowSlots(i)}>
                      {timing.expanded ? (
                        <FontAwesomeIcon icon={faCircleChevronRight} />
                      ) : (
                        <FontAwesomeIcon icon={faCircleChevronDown} />
                      )}
                    </button>
                    <h3>
                      {timing.date} ({DAY_SYMBOLS[timing.day_no]})
                    </h3>
                  </div>
                  <div
                    className={`slots days ${timing.expanded ? "" : "hidden"}`}
                  >
                    {timing.slots.map((slot, j) => (
                      <button
                        onClick={() => bookSlot(i, j)}
                        disabled={!slot[2]}
                      >
                        {slot[1]}
                      </button>
                    ))}
                  </div>
                </div>
              ))
            )}
          </>
        )}
        <h2 className="title">APPOINTMENT FEEDBACKS</h2>
        {loading ? (
          <BoxLoader height="150px" />
        ) : appointmentFeedbacks.length > 0 ? (
          appointmentFeedbacks.map((feedback, i) => (
            <div className="feedback">
              <figure>
              <img
                src={feedback.patient.gender === 2 ? female : male}
                alt="Patient Avatar"
              />
              </figure>
              <div>
                <h3>
                  {feedback.patient.first_name} {feedback.patient.last_name}
                </h3>
                <p>
                  {feedback.uiStars.map((star, i) => (
                    <FontAwesomeIcon
                      icon={faStar}
                      color={star ? "orange" : "gray"}
                    />
                  ))}
                </p>
                <p>{feedback.review}</p>
              </div>
            </div>
          ))
        ) : (
          <p>No feedbacks yet</p>
        )}
      </div>
    </main>
  );
};

export default DoctorDetailsPage;
