import React, { useState, useEffect } from "react";
import { BoxLoader } from "../../widgets/loadings/loaders";
import { getFromServer } from "../../../globals/requests";
import { showErrorMsg } from "../../../globals/helpers";
import LineChart from "../../widgets/charts/LineChart";

const AdminDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [counts, setCounts] = useState({});
  const [appointmentChart, setAppointmentChart] = useState({});
  const [userChart, setUserChart] = useState({});
  const loadMyHabitActivitie = async () => {
    setLoading(true);
    const result = await getFromServer("/accounts/admin-dashboard-data");
    if (result.status) {
      setCounts(result.data.counts);
      setAppointmentChart(result.data.charts.appointments);
      setUserChart(result.data.charts.users);
    } else showErrorMsg(result.msg);
    setLoading(false);
  };

  useEffect(() => {
    loadMyHabitActivitie();
  }, []);

  return (
    <main>
      <div className="cont">
        <h2 className="title">ADMIN DASHBOARD</h2>
        {loading ? (
          <BoxLoader height="150px" />
        ) : (
          <>
            <div className="count-cont">
              <div className="count-box">
                <label>Total Users</label>
                <p>#{counts.users}</p>
              </div>
              <div className="count-box">
                <label>Total Doctors</label>
                <p>#{counts.doctors}</p>
              </div>
              <div className="count-box">
                <label>Total Patients</label>
                <p>#{counts.patients}</p>
              </div>
              <div className="count-box">
                <label>Appointments</label>
                <p>#{counts.appointments}</p>
              </div>
              <div className="count-box">
                <label>Feedbacks</label>
                <p>#{counts.appointment_feedbacks}</p>
              </div>
              <div className="count-box">
                <label>Invoice Amount</label>
                <p>${counts.invoice_amt}</p>
              </div>
            </div>
            <div style={{ height: "15px" }}></div>
            <div className="charts">
              {userChart.labels && userChart.data && (
                <div className="card">
                  <h3>User Registrations in last 7 days</h3>
                  <LineChart
                    labels={userChart.labels}
                    charData={userChart.data}
                    name="User Registrations in last 7 days"
                  />
                </div>
              )}
              {appointmentChart.labels && appointmentChart.data && (
                <div className="card">
                  <h3>Appointments in last 7 days</h3>
                  <LineChart
                    labels={appointmentChart.labels}
                    charData={appointmentChart.data}
                    name="Appointments in last 7 days"
                  />
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </main>
  );
};

export default AdminDashboard;
