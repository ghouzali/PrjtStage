import React, { useRef, useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { startLoading, stopLoading } from "../../../app/slices/uiSlice";
import { getFromServer, putToServer } from "../../../globals/requests";
import { showErrorMsg, showStatusMsg } from "../../../globals/helpers";
import { DAY_SYMBOLS } from "../../../globals/constants";
import { BtnWaiting } from "../../widgets/loadings/Buttons";

const Schedules = () => {
  const dispatch = useDispatch();
  const [saving, setSaving] = useState(false);
  const [availDays, setAvailDays] = useState([]);
  const available = useRef(null);
  const availStTime = useRef(null);
  const availEndTime = useRef(null);
  const appointmentFee = useRef(null);
  const specialty = useRef(null);
  const acceptInsurances = useRef(null);
  const kindOdDiseases = useRef(null);
  const language = useRef(null);

  const loadSchedule = async () => {
    dispatch(startLoading());
    try {
      const result = await getFromServer(`/accounts/my-schedule`);
      if (result.status) {
        setAvailDays(result.data.avail_days);
        availStTime.current.value = result.data.avail_st_time;
        availEndTime.current.value = result.data.avail_end_time;
        available.current.value = result.data.available ? 1 : 0;
        appointmentFee.current.value = result.data.appointment_fee;
        specialty.current.value = result.data.specialty || "";
        acceptInsurances.current.value = result.data.accept_insurances ? 1 : 0;
        kindOdDiseases.current.value = result.data.kind_of_diseases || "";
        language.current.value = result.data.language || "";
      } else showErrorMsg(result.msg);
    } catch (error) {}
    dispatch(stopLoading());
  };
  const dayClick = (i) => {
    const temp = [...availDays];
    temp[i] = !temp[i];
    setAvailDays(temp);
  };
  const saveSchedule = async (e) => {
    e.preventDefault();
    const stTime = availStTime.current.value;
    const endTime = availEndTime.current.value;
    const data = {
      avail_days: availDays,
      avail_st_time: stTime,
      avail_end_time: endTime,
      available: available.current.value == 1 ? true : false,
      appointment_fee: appointmentFee.current.value,
      specialty: specialty.current.value ? specialty.current.value : null,
      accept_insurances: acceptInsurances.current.value == 1 ? true : false,
      kind_of_diseases: kindOdDiseases.current.value ? kindOdDiseases.current.value : null,
      language: language.current.value ? language.current.value : null,
    };

    // Validation: Check if start time is less than end time
    if (new Date(`2000-01-01T${stTime}`) >= new Date(`2000-01-01T${endTime}`)) {
      showErrorMsg("Start time must be less than end time.");
      return false;
    }

    setSaving(true);
    const result = await putToServer(`/accounts/my-schedule`, data);
    setSaving(false);
    if (result.status) {
    }
    showStatusMsg(result.status, result.msg);
  };

  useEffect(() => {
    loadSchedule();
  }, []);

  return (
    <main>
      <div className="cont">
        <h2 className="title">MY APPOINTMENT SCHEDULES</h2>
        <h3 style={{ marginBottom: "10px" }}>Days Availability</h3>
        <div className="days">
          {availDays.map((day, i) => (
            <button className={day ? "active" : ""} onClick={() => dayClick(i)}>
              {DAY_SYMBOLS[i]}
            </button>
          ))}
        </div>
        <h3 style={{ marginBottom: "10px" }}>Daily Availability Timings</h3>
        <form className="form" onSubmit={saveSchedule}>
          <p>
            <label htmlFor="available">Availability</label>
            <select id="available" ref={available} required>
              <option value="0">NO</option>
              <option value="1">YES</option>
            </select>
          </p>
          <p>
            <label htmlFor="appointment_fee">Appointment Fee</label>
            <input
              type="number"
              id="appointment_fee"
              ref={appointmentFee}
              required
            />
          </p>
          <p>
            <label htmlFor="avail_st_time">Availability Start Time</label>
            <input type="time" id="avail_st_time" ref={availStTime} required />
          </p>
          <p>
            <label htmlFor="avail_st_time">Availability End Time</label>
            <input type="time" id="avail_st_time" ref={availEndTime} required />
          </p>
          <p>
            <label htmlFor="specialty">Specialty</label>
            <select id="specialty" ref={specialty} required>
              <option value="">Select Specialty</option>
              <option value="1">Cardiologist</option>
              <option value="2">Dermatologist</option>
              <option value="3">Neurologist</option>
              <option value="4">Pediatrician</option>
              <option value="5">Ophthalmologist</option>
              <option value="6">Gastroenterologist</option>
            </select>
          </p>
          <p>
            <label htmlFor="accept_insurances">Accept Insurances</label>
            <select id="accept_insurances" ref={acceptInsurances} required>
              <option value="0">NO</option>
              <option value="1">YES</option>
            </select>
          </p>
          <p>
            <label htmlFor="kind_of_diseases">Kind of Diseases</label>
            <select id="kind_of_diseases" ref={kindOdDiseases} required>
              <option value="">Select kind of diseases</option>
              <option value="1">Infectious Diseases</option>
              <option value="2">Chronic Diseases</option>
              <option value="3">Respiratory Diseases</option>
              <option value="4">Cardiovascular Diseases</option>
              <option value="5">Mental Health Disorders</option>
              <option value="6">Inflammatory Conditions</option>
              <option value="7">Infectious Diseases</option>
              <option value="8">Cancer</option>
            </select>
          </p>
          <p>
            <label htmlFor="language">Language</label>
            <select id="language" ref={language} required>
              <option value="">Select Language</option>
              <option value="1">English</option>
              <option value="2">French</option>
              <option value="3">Breton</option>
            </select>
          </p>
          <div className="full">
            {saving ? (
              <BtnWaiting />
            ) : (
              <button className="btn">Save Schedule</button>
            )}
          </div>
        </form>
      </div>
    </main>
  );
};

export default Schedules;
