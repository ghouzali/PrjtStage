import React, { useRef, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getFromServer, postToServer } from "../../../globals/requests";
import { showErrorMsg, showStatusMsg } from "../../../globals/helpers";
import male from "../../../assets/images/male.png";
import female from "../../../assets/images/female.png";
import ChatArea from "../accounts/ChatArea";
import { BoxLoader } from "../../widgets/loadings/loaders";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCalendarDays,
  faClock,
  faStar,
} from "@fortawesome/free-solid-svg-icons";

const DoctorAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [chatAppointId, setChatAppointId] = useState(null);

  const loadMyAppointments = async () => {
    setLoading(true);
    const result = await getFromServer("/activities/doctor-appointments");
    if (result.status) {
      setAppointments(result.data);
    } else showErrorMsg(result.msg);
    setLoading(false);
  };

  const cancelAppointment = async (index) => {
    const id = appointments[index].id;
    const msg =
      "Do you really want to Cancel this Appointment? This process will not able to undone.";
    if (window.confirm(msg)) {
      const result = await postToServer(`/activities/appointment/${id}/cancel`);
      if (result.status) {
        const temp = [...appointments];
        temp[index].status = false;
        setAppointments(temp);
      }
      showStatusMsg(result.status, result.msg);
    }
  };

  useEffect(() => {
    loadMyAppointments();
  }, []);

  return (
    <main>
      <div className="cont">
        <h2 className="title">MY APPOINTMENTS</h2>
        {loading ? (
          <BoxLoader height="150px" />
        ) : appointments.length > 0 ? (
          <div className="doctors">
            {appointments.map((appoint, i) => (
              <div className="doctor" key={appoint.id}>
                <div className="info">
                  <figure>
                    <img
                      src={appoint.patient.gender === 2 ? female : male}
                      alt="Doctor Avatar"
                    />
                  </figure>
                  <div>
                    <h3>
                      {appoint.patient.first_name} {appoint.patient.last_name}
                    </h3>
                    <h4>@{appoint.patient.username}</h4>
                    {/* <h4>Time Slot</h4> */}
                    <p>
                      <FontAwesomeIcon icon={faCalendarDays} color="green" />{" "}
                      {appoint.date}
                    </p>
                    <p>
                      <FontAwesomeIcon icon={faClock} color="green" />{" "}
                      {appoint.st_time} - {appoint.end_time}
                    </p>
                  </div>
                </div>
                <div
                  style={{ marginBottom: "10px" }}
                  className="appoint-actions"
                >
                  <span>
                    Status:{" "}
                    {appoint.ended ? (
                      <b style={{ color: "gray" }}>ENDED</b>
                    ) : appoint.status ? (
                      <b style={{ color: "green" }}>ACTIVE</b>
                    ) : (
                      <b style={{ color: "red" }}>CANCELLED</b>
                    )}
                  </span>
                  <Link to="#" onClick={() => setChatAppointId(appoint.id)}>
                    Chat
                  </Link>
                </div>
                <div className="appoint-actions">
                  {!appoint.ended ||
                    (appoint.status && (
                      <>
                        <Link to="#">Reschedule</Link>
                        <Link to="#" onClick={() => cancelAppointment(i)}>
                          Cancel
                        </Link>
                      </>
                    ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ textAlign: "center" }}>No Appointment yet</p>
        )}
      </div>
      {chatAppointId && (
        <ChatArea
          chatAppointId={chatAppointId}
          setChatAppointId={setChatAppointId}
        />
      )}
    </main>
  );
};

export default DoctorAppointments;
