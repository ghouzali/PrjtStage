import React, { useRef, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getFromServer, postToServer } from "../../../globals/requests";
import { showErrorMsg, showStatusMsg } from "../../../globals/helpers";
import maleDoctor from "../../../assets/images/male-doctor.png";
import femaleDoctor from "../../../assets/images/female-doctor.png";
import Popup from "../../widgets/Popup";
import { BtnWaiting } from "../../widgets/loadings/Buttons";
import { BoxLoader } from "../../widgets/loadings/loaders";
import ChatArea from "../accounts/ChatArea";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCalendarDays,
  faClock,
  faStar,
} from "@fortawesome/free-solid-svg-icons";

const MyAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [loading, setLoading] = useState(true);
  const [chatAppointId, setChatAppointId] = useState(null);

  const [feedback, setFeedback] = useState({
    appointment_id: null,
    stars: 0,
    uiStars: [false, false, false, false, false],
    review: useRef(null),
  });
  const [saving, setSaving] = useState(false);
  const [feedbackLoading, setFeedbackLoading] = useState(false);
  const setStars = (stars) => {
    const uiStars = [false, false, false, false, false];
    for (let i = 0; i < stars; i++) uiStars[i] = true;
    setFeedback({ ...feedback, stars: stars, uiStars: uiStars });
  };
  const resetFeedBack = (popupState) => {
    const temp = { ...feedback };
    temp.appointment_id = null;
    temp.stars = 0;
    temp.uiStars = [false, false, false, false, false];
    temp.review.current.value = "";
    setFeedback(temp);
    setShowPopup(popupState);
  };
  const saveFeedback = async (e) => {
    e.preventDefault();
    setSaving(true);
    const url = `/activities/appointment/${feedback.appointment_id}/feedback`;
    const result = await postToServer(url, {
      stars: feedback.stars,
      review: feedback.review.current.value,
    });
    if (result.status) resetFeedBack(false);
    showStatusMsg(result.status, result.msg);
    setSaving(false);
  };

  const loadMyAppointments = async () => {
    setLoading(true);
    const result = await getFromServer("/activities/my-appointments");
    if (result.status) {
      setAppointments(result.data);
    } else showErrorMsg(result.msg);
    setLoading(false);
  };

  const showFeedbacks = async (id) => {
    setShowPopup(true);
    setFeedbackLoading(true);
    const result = await getFromServer(
      `/activities/appointment/${id}/feedback`
    );
    if (result.status) {
      const uiStars = [false, false, false, false, false];
      for (let i = 0; i < result.data.stars; i++) uiStars[i] = true;
      setFeedback({
        ...feedback,
        appointment_id: id,
        stars: result.data.stars,
        uiStars: uiStars,
      });
      feedback.review.current.value = result.data.review;
    } else showErrorMsg(result.msg);
    setFeedbackLoading(false);
  };

  const cancelAppointment = async (index) => {
    const id = appointments[index].id;
    const msg =
      "Do you really want to Cancel this Appointment? This process will not able to undone.";
    if (window.confirm(msg)) {
      const result = await postToServer(`/activities/appointment/${id}/cancel`);
      if (result.status) {
        const temp = [...appointments];
        temp[index].status = false;
        setAppointments(temp);
      }
      showStatusMsg(result.status, result.msg);
    }
  };

  useEffect(() => {
    loadMyAppointments();
  }, []);

  return (
    <main>
      <div className="cont">
        <h2 className="title">MY APPOINTMENTS</h2>
        {loading ? (
          <BoxLoader height="150px" />
        ) : appointments.length > 0 ? (
          <div className="doctors">
            {appointments.map((appoint, i) => (
              <div className="doctor" key={appoint.id}>
                <div className="info">
                  <figure>
                    <img
                      src={
                        appoint.doctor.gender === 2 ? femaleDoctor : maleDoctor
                      }
                      alt="Doctor Avatar"
                    />
                  </figure>
                  <div>
                    <h3>
                      {appoint.doctor.first_name} {appoint.doctor.last_name}
                    </h3>
                    <h4>@{appoint.doctor.username}</h4>
                    {/* <h4>Time Slot</h4> */}
                    <p>
                      <FontAwesomeIcon icon={faCalendarDays} color="green" />{" "}
                      {appoint.date}
                    </p>
                    <p>
                      <FontAwesomeIcon icon={faClock} color="green" />{" "}
                      {appoint.st_time} - {appoint.end_time}
                    </p>
                  </div>
                </div>
                <div
                  style={{ marginBottom: "10px" }}
                  className="appoint-actions"
                >
                  <span>
                    Status:{" "}
                    {appoint.ended ? (
                      <b style={{ color: "gray" }}>ENDED</b>
                    ) : appoint.status ? (
                      <b style={{ color: "green" }}>ACTIVE</b>
                    ) : (
                      <b style={{ color: "red" }}>CANCELLED</b>
                    )}
                  </span>
                  <Link to="#" onClick={() => setChatAppointId(appoint.id)}>
                    Chat
                  </Link>
                </div>
                <div className="appoint-actions">
                  {appoint.ended || !appoint.status ? (
                    <Link to="#" onClick={() => showFeedbacks(appoint.id)}>
                      Feedback
                    </Link>
                  ) : (
                    <>
                      <Link to="#">Reschedule</Link>
                      <Link to="#" onClick={() => cancelAppointment(i)}>
                        Cancel
                      </Link>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ textAlign: "center" }}>No Appointment yet</p>
        )}
      </div>
      <Popup lg show={showPopup} title="Feedbacks" setShow={resetFeedBack}>
        {feedbackLoading && <BoxLoader height="150px" />}
        <form
          className="form full"
          onSubmit={saveFeedback}
          style={{ display: feedbackLoading ? "none" : "flex" }}
        >
          <p>
            <label>Rating</label>
            <span>
              {feedback.uiStars.map((star, i) => (
                <FontAwesomeIcon
                  icon={faStar}
                  color={star ? "orange" : "gray"}
                  onClick={() => setStars(i + 1)}
                />
              ))}
            </span>
          </p>
          <p>
            <label htmlFor="review">Review</label>
            <textarea rows="3" ref={feedback.review} required></textarea>
          </p>
          <div className="btn-gp" style={{ textAlign: "end" }}>
            {saving ? (
              <BtnWaiting />
            ) : (
              <button className="btn">Save Feedback</button>
            )}
          </div>
        </form>
      </Popup>
      {chatAppointId && (
        <ChatArea
          chatAppointId={chatAppointId}
          setChatAppointId={setChatAppointId}
        />
      )}
    </main>
  );
};

export default MyAppointments;
