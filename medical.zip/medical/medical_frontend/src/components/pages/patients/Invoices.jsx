import React, { useRef, useEffect, useState } from "react";
import { getFromServer, postToServer } from "../../../globals/requests";
import { showErrorMsg, showStatusMsg } from "../../../globals/helpers";
import { BtnWaiting } from "../../widgets/loadings/Buttons";
import { BoxLoader } from "../../widgets/loadings/loaders";

const Invoices = () => {
  const [appointInvoices, setAppointInvoices] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadInvoices = async () => {
    const result = await getFromServer("/activities/my-invoices");
    if (result.status) {
      setAppointInvoices(result.data);
    } else showErrorMsg(result.msg);
    setLoading(false);
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  return (
    <main>
      <div className="cont">
        <h2 className="title">APPOINTMENT INVOICES</h2>
        {loading ? (
          <BoxLoader height="150px" />
        ) : appointInvoices.length > 0 ? (
          <div className="tbl-box">
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Service</th>
                  <th>Time Slot</th>
                  <th>Doctor</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                {appointInvoices.map((appInvoice, i) => (
                  <tr>
                    <th>{i + 1}</th>
                    <td>Apppointment</td>
                    <td>
                      {appInvoice.appointment.date} (
                      {appInvoice.appointment.st_time} -{" "}
                      {appInvoice.appointment.end_time})
                    </td>
                    <td>
                      {appInvoice.doctor.first_name}{" "}
                      {appInvoice.doctor.last_name}
                    </td>
                    <td>
                      ${appInvoice.amount}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p style={{ textAlign: "center" }}>No Record found</p>
        )}
      </div>
    </main>
  );
};

export default Invoices;
