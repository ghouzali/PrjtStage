import React, { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faRightToBracket,
  faUser,
  faKey,
  faLock,
  faStethoscope,
} from "@fortawesome/free-solid-svg-icons";

import { useDispatch } from "react-redux";
import { login } from "../../../app/slices/authSlice";

import { BtnWaiting } from "../../widgets/loadings/Buttons";
import { postToServer } from "../../../globals/requests";
import { showStatusMsg } from "../../../globals/helpers";

const Login = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const refs = {
    username: useRef(null),
    password: useRef(null),
  };
  const [logging, setLogging] = useState(false);

  const submitForm = async (e) => {
    e.preventDefault();
    setLogging(true);
    const data = {
      username: refs.username.current.value.trim(),
      password: refs.password.current.value,
    };
    const result = await postToServer(`/login`, data);
    if (result.status) {
      if (result.data.token) {
        dispatch(login(result.data));
        showStatusMsg(true, result.msg);
      } else showStatusMsg(false, result.msg);
    } else showStatusMsg(result.status, result.msg);
    setLogging(false);
  };
  return (
    <div className="login-cont">
      <h1><FontAwesomeIcon icon={faStethoscope} />DigiMed</h1>
      <div className="card">
        <h2>
          <FontAwesomeIcon icon={faLock} /> LOGIN
        </h2>
        <form className="i-form" onSubmit={submitForm}>
          <p>
            <FontAwesomeIcon icon={faUser} color="green" />
            <input
              type="text"
              ref={refs.username}
              placeholder="Username"
              required
            />
          </p>
          <p>
            <FontAwesomeIcon icon={faKey} color="green" />
            <input
              type="password"
              ref={refs.password}
              placeholder="Password"
              required
            />
          </p>
          <div style={{ textAlign: "center" }}>
            {logging ? (
              <BtnWaiting />
            ) : (
              <button className="btn">
                <FontAwesomeIcon icon={faRightToBracket} /> LOGIN
              </button>
            )}
          </div>
        </form>
        <p style={{ textAlign: "center", marginTop: "10px" }}>
          Not registered yet? <Link to="/registration"> Please Register</Link>
        </p>
      </div>
    </div>
  );
};

export default Login;
