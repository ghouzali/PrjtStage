import React, { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faRightToBracket,
  faUser,
  faKey,
  faPenToSquare,
  faEnvelope,
  faIdCard,
  faStethoscope,
} from "@fortawesome/free-solid-svg-icons";

import { useDispatch } from "react-redux";
import { login } from "../../../app/slices/authSlice";

import { BtnWaiting } from "../../widgets/loadings/Buttons";
import { postToServer } from "../../../globals/requests";
import { showStatusMsg, showErrorMsg } from "../../../globals/helpers";

const Registration = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const refs = {
    firstName: useRef(null),
    lastName: useRef(null),
    username: useRef(null),
    role: useRef(null),
    email: useRef(null),
    gender: useRef(null),
    password: useRef(null),
    confPassword: useRef(null),
  };
  const [saving, setSaving] = useState(false);

  const submitForm = async (e) => {
    e.preventDefault();
    const pwd = refs.password.current.value;
    if (pwd === refs.confPassword.current.value) {
      setSaving(true);
      const data = {
        first_name: refs.firstName.current.value.trim(),
        last_name: refs.lastName.current.value.trim(),
        username: refs.username.current.value.trim(),
        email: refs.email.current.value.trim(),
        role: parseInt(refs.role.current.value),
        gender: parseInt(refs.gender.current.value),
        password: pwd,
      };
      const result = await postToServer(`/user-registration`, data);
      if (result.status) {
        if (result.data.token) {
          dispatch(login(result.data));
          showStatusMsg(true, result.msg);
        } else showStatusMsg(false, result.msg);
      } else showStatusMsg(result.status, result.msg);
      setSaving(false);
    } else showErrorMsg("Password and confirm password should match");
  };

  return (
    <div className="login-cont">
      <h1><FontAwesomeIcon icon={faStethoscope} />DigiMed</h1>
      <div className="card">
        <h2>
          <FontAwesomeIcon icon={faPenToSquare} /> Registration
        </h2>
        <form className="i-form" onSubmit={submitForm}>
          <p>
            <FontAwesomeIcon icon={faIdCard} color="green" />
            <input
              type="text"
              ref={refs.firstName}
              placeholder="First Name"
              required
            />
          </p>
          <p>
            <FontAwesomeIcon icon={faIdCard} color="green" />
            <input
              type="text"
              ref={refs.lastName}
              placeholder="Last Name"
              required
            />
          </p>
          <p>
            <FontAwesomeIcon icon={faUser} color="green" />
            <input
              type="text"
              ref={refs.username}
              name="username"
              placeholder="Username"
              required
            />
          </p>
          <p>
            <FontAwesomeIcon icon={faEnvelope} color="green" />
            <select ref={refs.role} required>
              <option value="">Select User role</option>
              <option value="2">Doctor</option>
              <option value="3">Patient</option>
            </select>
          </p>
          <p>
            <FontAwesomeIcon icon={faEnvelope} color="green" />
            <select ref={refs.gender} required>
              <option value="">Seleect you gender</option>
              <option value="1">Male</option>
              <option value="2">Female</option>
            </select>
          </p>
          <p>
            <FontAwesomeIcon icon={faEnvelope} color="green" />
            <input type="email" ref={refs.email} placeholder="Email" required />
          </p>
          <p>
            <FontAwesomeIcon icon={faKey} color="green" />
            <input
              type="password"
              ref={refs.password}
              placeholder="Password"
              required
            />
          </p>
          <p>
            <FontAwesomeIcon icon={faKey} color="green" />
            <input
              type="password"
              ref={refs.confPassword}
              placeholder="Confirm Password"
              required
            />
          </p>
          <div style={{ textAlign: "center" }}>
            {saving ? (
              <BtnWaiting />
            ) : (
              <button className="btn">
                <FontAwesomeIcon icon={faRightToBracket} /> REGISTER
              </button>
            )}
          </div>
        </form>
        <p style={{ textAlign: "center", marginTop: "10px" }}>
          Already registered? <Link to="/login"> Please Login</Link>
        </p>
      </div>
    </div>
  );
};

export default Registration;
