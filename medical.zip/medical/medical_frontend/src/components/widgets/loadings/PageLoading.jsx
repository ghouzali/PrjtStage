import React from "react";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSpinner } from "@fortawesome/free-solid-svg-icons";
import { useSelector } from "react-redux";

const PageLoading = () => {
  const loading = useSelector((state) => state.ui.loading);
  return (
    <div className="page-loader" style={{ display: loading ? "flex" : "none" }}>
      <FontAwesomeIcon icon={faSpinner} pulse />
    </div>
  );
};

export default PageLoading;
