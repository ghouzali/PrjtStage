import React from "react";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSpinner } from "@fortawesome/free-solid-svg-icons";
import { useSelector } from "react-redux";

const BoxLoader = ({height = "50px"}) => {
  return (
    <div className="box-loader" style={{ height: height }}>
      <FontAwesomeIcon icon={faSpinner} pulse />
    </div>
  )
}

export {BoxLoader};