import React from "react";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSpinner } from "@fortawesome/free-solid-svg-icons";

const BtnWaiting = () => {
  return (
    <button className="btn" disabled>
      <FontAwesomeIcon icon={faSpinner} pulse /> PLEASE WAIT....
    </button>
  );
};

export { BtnWaiting };
