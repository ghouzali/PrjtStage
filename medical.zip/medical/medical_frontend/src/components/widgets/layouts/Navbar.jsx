import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faBars,
  faUser,
  faStethoscope,
  faHouse,
} from "@fortawesome/free-solid-svg-icons";

import { postToServer } from "../../../globals/requests";
import { useDispatch } from "react-redux";
import { logout } from "../../../app/slices/authSlice";
import { showStatusMsg } from "../../../globals/helpers";

const Navbar = () => {
  const user = useSelector((state) => state.auth.user);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const dispatch = useDispatch();
  const logoutUser = async () => {
    dispatch(logout());
    showStatusMsg(true, "Logged out successfully.");
    await postToServer(`/logout`);
  };
  const closeDrawer = () => setDrawerOpen(false);
  const openDrawer = () => setDrawerOpen(true);

  return (
    <nav className="navbar">
      <button id="menu-btn" onClick={openDrawer}>
        <FontAwesomeIcon icon={faBars} />
      </button>
      <div className="logo">
        <FontAwesomeIcon icon={faStethoscope} />
        DigiMed
      </div>
      <div
        className={`overlay ${drawerOpen && "show"}`}
        onClick={closeDrawer}
      ></div>
      <div className={`links ${drawerOpen && "show"}`}>
        {user.role === 1 && (
          <>
            <Link to="/">
              <FontAwesomeIcon icon={faHouse} />
            </Link>
            <Link to="/admin/dashboard">AdminDashboard</Link>
          </>
        )}
        {user.role === 2 && (
          <>
            <Link to="/">
              <FontAwesomeIcon icon={faHouse} />
            </Link>
            <Link to="/accounts/schedules">Schedules</Link>
            <Link to="/accounts/doctor/appointments">Appointments</Link>
          </>
        )}
        {user.role === 3 && (
          <>
            <Link to="/">
              <FontAwesomeIcon icon={faHouse} />
            </Link>
            <Link to="/doctors">Doctors</Link>
            <Link to="/accounts/my-appointments">Appointments</Link>
            <Link to="/accounts/my-invoices">Invoices</Link>
          </>
        )}
        <Link to="/accounts/my-health-habits">Activities</Link>
      </div>
      <div>
        <div className="dropdown">
          <button>
            <FontAwesomeIcon icon={faUser} />
          </button>
          <div>
            <Link to="/accounts/profile">My Profile</Link>

            <Link onClick={logoutUser} to="#">
              Logout
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
