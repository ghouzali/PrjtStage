import React from "react";
import { Line } from "react-chartjs-2";
import {Char as CharJS} from 'chart.js/auto';

const LineChart = ({labels, charData, name}) => {
  // Data for the Line Chart
  const data = {
    // labels: ["January", "February", "March", "April", "May", "June", "July"],
    labels: labels,
    datasets: [
      {
        // label: "Monthly Sales",
        label: name,
        // data: [65, 59, 80, 81, 56, 55, 40],
        data: charData,
        fill: false,
        borderColor: "rgb(75, 192, 192)",
        tension: 0.1,
      },
    ],
  };

  return <Line data={data} />;
};

export default LineChart;
