import React from "react";

// icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faXmarkSquare } from "@fortawesome/free-solid-svg-icons";

const Popup = (props) => {
  const close = () => props.setShow(false);
  return (
    <div
      className={`popup ${props.show ? "show" : ""} ${props.lg ? "lg" : ""}`}
    >
      <div className="overlay" onClick={close}></div>
      <div className="content">
        <h2 style={{ paddingTop: "-5px", display: "inline-block" }}>
          {props.title}
        </h2>
        <FontAwesomeIcon
          id="close-btn"
          icon={faXmarkSquare}
          onClick={close}
          color="green"
        />
        <div className="divider"></div>
        <div>{props.children}</div>
        {/* <div style={{ textAlign: "end" }}>
          <button className="btn pri" onClick={close}>
            OK
          </button>
        </div> */}
      </div>
    </div>
  );
};

export default Popup;
