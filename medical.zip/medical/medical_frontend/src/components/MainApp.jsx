import React from "react";
import {
  createBrowserRouter,
  RouterProvider,
  redirect,
} from "react-router-dom";
import { useSelector } from "react-redux";

// layouts
import HomeLayout from "./widgets/layouts/HomeLayout";
// pages
import Login from "./pages/auth/Login";
import Home from "./pages/home/Home";
import DoctorDetailsPage from "./pages/home/DoctorDetailsPage";
import MyProfile from "./pages/accounts/MyProfile";
import Registration from "./pages/auth/Registration";
// doctors pages
import Schedules from "./pages/doctors/Schedules";
// patients pages
import MyAppointments from "./pages/patients/MyAppointments";
import MyHealthHabits from "./pages/accounts/MyHealthHabits";
import AddHealthHabit from "./pages/accounts/AddHealthHabit";
import AdminDashboard from "./pages/admin/AdminDashboard";
import DoctorAppointments from "./pages/doctors/DoctorAppointments";
import Invoices from "./pages/patients/Invoices";
import DoctorList from "./pages/home/DoctorList";

const MainApp = () => {
  const isLoggedIn = useSelector((state) => state.auth.isLoggedIn);
  const user = useSelector((state) => state.auth.user);

  const router = createBrowserRouter([
    {
      path: "/",
      element: <HomeLayout />,
      children: [
        {
          path: "/",
          element: <Home />,
        },
        {
          path: "accounts/profile",
          element: <MyProfile />,
        },
        {
          path: "doctors",
          element: <DoctorList />,
        },
        {
          path: "doctor/:username",
          element: <DoctorDetailsPage />,
        },
        {
          path: "accounts/schedules",
          element: <Schedules />,
          loader: async () =>
            user.role === 2 ? null : redirect("/accounts/profile"),
        },
        {
          path: "accounts/doctor/appointments",
          element: <DoctorAppointments />,
          loader: async () =>
            user.role === 2 ? null : redirect("/accounts/profile"),
        },
        {
          path: "accounts/my-appointments",
          element: <MyAppointments />,
        },
        {
          path: "accounts/my-invoices",
          element: <Invoices />,
        },
        {
          path: "accounts/my-health-habits",
          element: <MyHealthHabits />,
        },
        {
          path: "accounts/add-health-habits",
          element: <AddHealthHabit />,
        },
        {
          path: "admin/dashboard",
          element: <AdminDashboard />,
          loader: async () =>
            user.role === 1 ? null : redirect("/accounts/profile"),
        },
      ],
      loader: async () => (isLoggedIn ? null : redirect("/login")),
    },
    {
      path: "/login",
      element: <Login />,
      loader: async () => (isLoggedIn ? redirect("/") : null),
    },
    {
      path: "/registration",
      element: <Registration />,
      loader: async () => (isLoggedIn ? redirect("/") : null),
    },
  ]);
  return <RouterProvider router={router} />;
};

export default MainApp;
