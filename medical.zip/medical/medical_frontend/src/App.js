import React, { useEffect } from "react";
import { useDispatch } from 'react-redux';
import { loadAuthData } from './app/slices/authSlice';

// notification library.
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// css files
// import './App.css';
import "./assets/styles/index.css";
import "./assets/styles/responsive.css";

// components
import MainApp from "./components/MainApp";
import PageLoading from "./components/widgets/loadings/PageLoading";

const App = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(loadAuthData());
  }, [])

  return (
    <>
      <MainApp />
      <PageLoading />
      <ToastContainer position="top-right" theme="colored" />
    </>
  );
};

export default App;
