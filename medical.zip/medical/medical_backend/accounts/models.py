from django.db import models
from django.contrib.auth.models import AbstractUser

# constants
ROLES = ((1, 'Administrators'), (2, 'Doctor'), (3, 'Patient'))

GENDER = ((1, 'Male'), (2, 'Female'), (3, 'Others'))

SPECIALITIES = ((1, 'Cardiologist'), (2, 'Dermatologist'), (3, 'Neurologist'), (4, 'Pediatrician'), (5, 'Ophthalmologist'), (6, 'Gastroenterologist'))
SPECIALITIES_DICT = {1: 'Cardiologist', 2: 'Dermatologist', 3: 'Neurologist', 4: 'Pediatrician', 5: 'Ophthalmologist', 6: 'Gastroenterologist'}

KIND_OF_DISEASES = ((1, 'Infectious Diseases'), (2, 'Chronic Diseases'), (3, 'Respiratory Diseases'), (4, 'Cardiovascular Diseases'), (5, 'Mental Health Disorders'), (6, 'Inflammatory Conditions'), (7, 'Infectious Diseases'), (8, 'Cancer'))
KIND_OF_DISEASES_DICT= {1: 'Infectious Diseases', 2: 'Chronic Diseases', 3: 'Respiratory Diseases', 4: 'Cardiovascular Diseases', 5: 'Mental Health Disorders', 6: 'Inflammatory Conditions', 7: 'Infectious Diseases', 8: 'Cancer'}

LANGUAGES = ((1, 'English'), (2, 'French'), (3, 'Breton'))

def default_days():
    return [True, True, True, True, True, False, False]

# Create your models here.
class User(AbstractUser):
    # profile_pic = models.ImageField(upload_to='user_pics/', null=True)
    role = models.SmallIntegerField(default=3, choices=ROLES)
    gender = models.SmallIntegerField(default=1, choices=GENDER)

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    about = models.TextField(null=True, blank=True)

class DoctorProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    avail_st_time = models.TimeField(null=True)
    avail_end_time = models.TimeField(null=True)
    avail_days = models.JSONField(default=default_days)
    available = models.BooleanField(default=False)
    appointment_fee = models.FloatField(null=True)
    specialty = models.SmallIntegerField(choices=SPECIALITIES, null=True)
    accept_insurances = models.BooleanField(default=False)
    kind_of_diseases = models.SmallIntegerField(choices=KIND_OF_DISEASES, null=True)
    language = models.SmallIntegerField(choices=LANGUAGES, null=True)

