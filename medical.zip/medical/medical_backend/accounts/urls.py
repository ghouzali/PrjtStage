from django.urls import path
from . import views

urlpatterns = [
    path('my-profile', views.profile),
    path('my-schedule', views.my_schedule),
    path('my-health-habits', views.my_health_habits),
    path('admin-dashboard-data', views.admin_dashboard_data),
]
