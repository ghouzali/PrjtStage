from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import DoctorProfile, User, UserProfile
from .serializers import UserSerializer, UserProfileSerializer
from activities.models import HealthActivity, Appointment, AppointmentFeedback, AppointmentInvoice
from activities.serializers import HealthActivitySerializer
from activities.ai_engine import generate_recommendations, get_health_data, load_model
from django.db.models import Sum, Count
from datetime import datetime, timedelta
# Create your views here.

@api_view(['GET', 'PUT'])
@permission_classes([IsAuthenticated])
def profile(request):
    user_profile = UserProfile.objects.get(user=request.user)
    if request.method == 'GET':
        return Response({
            "data": {
                "user": UserSerializer(request.user).data,
                "profile": UserProfileSerializer(user_profile).data
            },
            "msg": "Success."
        })
    elif request.method == 'PUT':
        data = request.data
        data['user']['username'] = request.user.username
        serializer = UserSerializer(request.user, data = data['user'])
        if serializer.is_valid():
            serializer.save()
        else:
            return Response(serializer.errors, status=400)
        data['profile']['user'] = request.user.id
        serializer = UserProfileSerializer(user_profile, data = data['profile'])
        if serializer.is_valid():
            serializer.save()
        else:
            return Response(serializer.errors, status=400)
        return Response({"data": {}, "msg": "Profile saved successfully."})

@api_view(['GET', 'PUT'])
@permission_classes([IsAuthenticated])
def my_schedule(request):
    try:
        dp = DoctorProfile.objects.get(user_id=request.user.id)
        if request.method == 'GET':
            return Response({
                "data": {
                    "avail_days": dp.avail_days,
                    "avail_st_time": dp.avail_st_time,
                    "avail_end_time": dp.avail_end_time,
                    "available": dp.available,
                    "appointment_fee": dp.appointment_fee,
                    "specialty": dp.specialty,
                    "accept_insurances": dp.accept_insurances,
                    "kind_of_diseases": dp.kind_of_diseases,
                    "language": dp.language,
                },
                "msg": "Success."
            })
        elif request.method == 'PUT':
            data = request.data
            dp.avail_days = data['avail_days']
            dp.avail_st_time = data['avail_st_time'] if data['avail_st_time'] else None
            dp.avail_end_time = data['avail_end_time'] if data['avail_end_time'] else None
            dp.available = data['available']
            dp.appointment_fee = data['appointment_fee']
            dp.specialty = data['specialty']
            dp.accept_insurances = data['accept_insurances']
            dp.kind_of_diseases = data['kind_of_diseases']
            dp.language = data['language']
            dp.save()
            return Response({"data": {}, "msg": "Schedule saved successfully."})
    except DoctorProfile.DoesNotExist:
        return Response({"data": {}, "msg": "Access Denied."}, 403)
    
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def my_health_habits(request):
    if request.method == 'GET':
        query = HealthActivity.objects.filter(user_id=request.user.id)
        return Response({"data": HealthActivitySerializer(query, many=True).data, "msg": "Success."})
    elif request.method == 'POST':

        model = load_model()
        recommendations = generate_recommendations(model, [get_health_data(request.data)])[0]

        request.data['user'] = request.user.id
        request.data['recommendations'] = recommendations
        serializer = HealthActivitySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"data": {}, "msg": "Health habit activities saved successfully."})
        else:
            return Response({"data": {}, "msg": "Bad reques."}, status=400)
    

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def admin_dashboard_data(request):
    if request.user.role == 1:
        seven_days_ago = datetime.now() - timedelta(days=7)
        all_dates = [(seven_days_ago + timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7)]
        data = {
            "counts": {
                "users": User.objects.count(),
                "doctors": User.objects.filter(role=2).count(),
                "patients": User.objects.filter(role=3).count(),
                "appointments": Appointment.objects.count(),
                "appointment_feedbacks": AppointmentFeedback.objects.count(),
                "invoice_amt": AppointmentInvoice.objects.aggregate(amt_sum=Sum('amount'))['amt_sum'],
            },
            "charts": {}
        }
    
        user_data = User.objects.filter(date_joined__gte=seven_days_ago).values('date_joined').annotate(count=Count('id'))
        appoint_by_date = {entry['date_joined'].strftime('%Y-%m-%d'): entry['count'] for entry in user_data}
        data["charts"]['users'] = {
            "labels": [date for date in all_dates],
            "data": [appoint_by_date.get(date, 0) for date in all_dates]
        }
    
        appoint_data = Appointment.objects.filter(date__gte=seven_days_ago).values('date').annotate(count=Count('id'))
        appoint_by_date = {entry['date'].strftime('%Y-%m-%d'): entry['count'] for entry in appoint_data}
        data["charts"]['appointments'] = {
            "labels": [date for date in all_dates],
            "data": [appoint_by_date.get(date, 0) for date in all_dates]
        }
    
        return Response({"data": data, "msg": "Success."})
    else:
        return Response({"data": {}, "msg": "Access Denied."}, status=403)