from rest_framework import serializers
from .models import Appointment, AppointmentFeedback, HealthActivity, AppointmentChat


class AppointmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = '__all__'

class AppointmentFeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = AppointmentFeedback
        fields = '__all__'

class HealthActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = HealthActivity
        fields = '__all__'

class AppointmentChatSerializer(serializers.ModelSerializer):
    class Meta:
        model = AppointmentChat
        fields = '__all__'
