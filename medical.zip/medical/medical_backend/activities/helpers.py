from datetime import datetime, timedelta, date
from.models import Appointment
from accounts.models import DoctorProfile
from django.db.models import Q

# constants
TIME_SLOT = 15 # time in minutes

def get_time_availability(doctor_id, avail_days, st_time, end_time):
    day = date.today()
    result = []
    for _ in range(7):
        day_no = day.weekday()
        if avail_days[day_no]:
            appoints = Appointment.objects.filter(doctor_id=doctor_id, date=day, status=True).values_list('st_time', 'end_time')
            slots = []
            start_dt = datetime.combine(day, st_time)
            end_dt = datetime.combine(day, end_time)
            while start_dt < end_dt:
                new_time = start_dt + timedelta(minutes=TIME_SLOT)
                active = True
                for appoint in appoints:
                    temp_st_time = start_dt.time()
                    temp_end_time = new_time.time()
                    if (appoint[0] >= temp_st_time and appoint[0] < temp_end_time) or (appoint[1] > temp_st_time and appoint[1] < temp_end_time):
                        active = False
                        break
                slots.append((
                    f'{start_dt.strftime("%H:%M")} - {new_time.strftime("%H:%M")}',
                    f'{start_dt.strftime("%I:%M %p")} - {new_time.strftime("%I:%M %p")}',
                    active,
                ))
                start_dt = new_time
            
            result.append({"date": day, "slots": slots, "expanded": False, "day_no": day_no})
        day += timedelta(days=1)
    return result
    
def check_time_slot_free(data):
    exists = Appointment.objects.filter(
        doctor_id=data['doctor_id'], date=data['date'], status=True
    ).filter(
        Q(Q(st_time__gte=data['st_time']) & Q(st_time__lt=data['end_time'])) | Q(Q(end_time__gt=data['st_time']) & Q(end_time__lt=data['end_time']))
    ).exists()
    return not exists