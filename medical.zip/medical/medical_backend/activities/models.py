from django.db import models
from accounts.models import User


# Create your models here.
class Appointment(models.Model):
    patient = models.ForeignKey(User, on_delete=models.PROTECT, related_name="appointment_patient")
    doctor = models.ForeignKey(User, on_delete=models.PROTECT, related_name="appointment_doctor")
    date = models.DateField()
    st_time = models.TimeField()
    end_time = models.TimeField()
    reschedule_count = models.SmallIntegerField(default=0)
    status = models.BooleanField(default=True)

    updated_on = models.DateTimeField(auto_now=True)
    created_on = models.DateTimeField(auto_now_add=True)

class AppointmentFeedback(models.Model):
    appointment = models.ForeignKey(Appointment, on_delete=models.PROTECT)
    stars = models.SmallIntegerField()
    review = models.TextField(null=True, blank=True)

    updated_on = models.DateTimeField(auto_now=True)
    created_on = models.DateTimeField(auto_now_add=True)

class AppointmentChat(models.Model):
    appointment = models.ForeignKey(Appointment, on_delete=models.PROTECT)
    msg = models.TextField(null=True)
    msg_by = models.ForeignKey(User, on_delete=models.PROTECT)
    seen = models.BooleanField(default=False)

    created_on = models.DateTimeField(auto_now_add=True)


QTY_CHOICES = ((1, "LOW"), (2, "MEDIUM"), (3, "HIGH"))

class HealthActivity(models.Model):
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    date = models.DateField()

    exercise = models.BooleanField()
    food_consumption = models.SmallIntegerField(choices=QTY_CHOICES)
    water_consumption = models.SmallIntegerField(choices=QTY_CHOICES)
    good_sleep = models.BooleanField()
    smoke = models.BooleanField()
    stress = models.SmallIntegerField(choices=QTY_CHOICES)
    screen_time = models.SmallIntegerField(choices=QTY_CHOICES)

    recommendations = models.CharField(max_length=255, null= True)
    updated_on = models.DateTimeField(auto_now=True)
    created_on = models.DateTimeField(auto_now_add=True)

# Invoicing
class AppointmentInvoice(models.Model):
    appointment = models.ForeignKey(Appointment, on_delete=models.PROTECT)
    amount = models.FloatField()

    updated_on = models.DateTimeField(auto_now=True)
    created_on = models.DateTimeField(auto_now_add=True)
