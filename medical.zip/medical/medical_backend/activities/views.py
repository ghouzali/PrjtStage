from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from accounts.models import DoctorProfile, User
from activities.helpers import get_time_availability, check_time_slot_free
from .models import Appointment, AppointmentFeedback, AppointmentInvoice, AppointmentChat
from datetime import datetime, timedelta, date
from .serializers import AppointmentSerializer, AppointmentChatSerializer


# Create your views here.

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def my_appointments(request):
    appoints = Appointment.objects.select_related('doctor').filter(patient_id=request.user.id).order_by('-id')
    data = []
    curr_date_time = datetime.now()
    for appoint in appoints:
        end_date = datetime.combine(appoint.date, appoint.end_time)
        data.append({
            "id": appoint.id, "st_time": appoint.st_time.strftime("%I:%M %p"),
            "end_time": appoint.end_time.strftime("%I:%M %p"), "date": appoint.date, "status": appoint.status,
            "ended": curr_date_time > end_date,
            "doctor": {
                "id": appoint.doctor.id,
                "first_name": appoint.doctor.first_name, "last_name": appoint.doctor.last_name,
                "username": appoint.doctor.username, "gender": appoint.doctor.gender
            }
        })
    return Response({"data": data, "msg": "Success."})

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def my_invoices(request):
    invoices =AppointmentInvoice.objects.select_related(
        'appointment'
    ).select_related(
        'appointment__doctor'
    ).filter(appointment__patient_id=request.user.id).order_by('-id')
    data = []
    for invoice in invoices:
        data.append({
            "id": invoice.id, "amount": invoice.amount,
            "appointment": {
                "date": invoice.appointment.date,
                "st_time": invoice.appointment.st_time,
                "end_time": invoice.appointment.end_time,
            },
            "doctor": {
                "first_name": invoice.appointment.doctor.first_name,
                "last_name": invoice.appointment.doctor.last_name,
            }
        })
    return Response({"data": data, "msg": "Success."})

@api_view(['GET', 'PUT'])
@permission_classes([IsAuthenticated])
def doctor_appointments(request):
    appoints = Appointment.objects.select_related('patient').filter(doctor_id=request.user.id).order_by('-id')
    data = []
    curr_date_time = datetime.now()
    for appoint in appoints:
        end_date = datetime.combine(appoint.date, appoint.end_time)
        data.append({
            "id": appoint.id, "st_time": appoint.st_time.strftime("%I:%M %p"),
            "end_time": appoint.end_time.strftime("%I:%M %p"), "date": appoint.date, "status": appoint.status,
            "ended": curr_date_time > end_date,
            "patient": {
                "id": appoint.patient.id,
                "first_name": appoint.patient.first_name, "last_name": appoint.patient.last_name,
                "username": appoint.patient.username, "gender": appoint.patient.gender
            }
        })
    return Response({"data": data, "msg": "Success."})

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def doctor_page_details(request, username):
    doc_user = User.objects.get(username=username)
    doc_pr = DoctorProfile.objects.get(user_id=doc_user.id)
    appointment_feedbacks = []
    feedbacks = AppointmentFeedback.objects.select_related("appointment__patient").filter(appointment__doctor_id=doc_user.id)
    for feedback in feedbacks:
        appointment_feedbacks.append({
            "id": feedback.id,
            "stars": feedback.stars, "review": feedback.review,
            "patient": {
                "first_name": feedback.appointment.patient.first_name,
                "last_name": feedback.appointment.patient.last_name,
            }
        })

    availability = []
    if request.user.id != doc_user.id:
        availability = get_time_availability(doc_user.id, doc_pr.avail_days, doc_pr.avail_st_time, doc_pr.avail_end_time)

    data = {
        "user": {
            "id": doc_user.id, "first_name": doc_user.first_name,
            "last_name": doc_user.last_name, "username": doc_user.username,
            "gender": doc_user.gender,
        },
        "profile": {
            "avail_days": doc_pr.avail_days,
            "avail_st_time": doc_pr.avail_st_time.strftime("%I:%M %p") if doc_pr.avail_st_time else None,
            "avail_end_time": doc_pr.avail_end_time.strftime("%I:%M %p") if doc_pr.avail_end_time else None
        },
        "appointment_feedbacks": appointment_feedbacks,
        "availability": availability
    }
    return Response({"data": data, "msg": "Success."})

@api_view(['POST'])
@permission_classes([IsAuthenticated])     
def book_appointment(request, id):
    if request.user.id == id:
        return Response({"data": {"booked": False}, "msg": "You can not book your own appointment."})
    doc_user = User.objects.get(id=id)
    doc_profile = DoctorProfile.objects.get(user_id=id)
    data = request.data
    data['doctor_id'] = doc_user.id
    if check_time_slot_free(data):
        appoint = Appointment.objects.create(
            doctor_id=doc_user.id, patient_id=request.user.id, date=data['date'],
            st_time=data['st_time'], end_time=data['end_time']
        )
        if doc_profile.appointment_fee:
            AppointmentInvoice.objects.create(
                appointment_id=appoint.id, amount=doc_profile.appointment_fee
            )
        return Response({"data": {"booked": True}, "msg": "Time slot booked successfully."})
    else:
        return Response({"data": {"booked": False}, "msg": "Selected time slot is not available."})

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])     
def appointment_feedback(request, id):
    try:
        feedback = AppointmentFeedback.objects.get(appointment_id=id)
    except AppointmentFeedback.DoesNotExist:
        feedback = AppointmentFeedback()
    if request.method == 'GET':
        if feedback.id:
            data = {"stars": feedback.stars, "review": feedback.review}
        else:
            data = {"stars": 0, "review": ""}
        return Response({"data": data, "msg": "Success."})
    elif request.method == 'POST':
        feedback.appointment_id=id
        feedback.stars=request.data['stars']
        feedback.review=request.data['review']
        feedback.save()
        return Response({"data": {}, "msg": "Feedback saved successfully."})

@api_view(['POST'])
@permission_classes([IsAuthenticated])     
def appointment_cancel(request, id):
    try:
        apoint = Appointment.objects.get(id=id)
        apoint.status = False
        apoint.save()
        return Response({"data": {}, "msg": "appointment cancelled successfully."})
    except Appointment.DoesNotExist:
        return Response({"data": {}, "msg": "Appointment not found."}, status=404)

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])     
def appointment_chats(request, id):
    user_id = request.user.id
    try:
        appoint = Appointment.objects.get(id=id)
        if appoint.patient_id == user_id or appoint.doctor_id == user_id:
            if request.method == 'GET':
                chats = AppointmentChat.objects.filter(appointment_id=appoint.id)
                AppointmentChat.objects.filter(appointment_id=appoint.id, seen=False).exclude(msg_by_id=user_id).update(seen=True)
                return Response({"data": AppointmentChatSerializer(chats, many=True).data, "msg": "Success."})
            elif request.method == 'POST':
                chat = AppointmentChat.objects.create(
                    appointment_id=appoint.id, msg_by_id=request.user.id,
                    msg= request.data['msg']
                )
                return Response({"data": {"created_on": chat.created_on}, "msg": "Success."})
            else:
                return Response({"data": {}, "msg": "Method not allowed."}, status=405)
        else:
            return Response({"data": {}, "msg": "Access Denied."}, status=405)
    except Appointment.DoesNotExist:
        return Response({"data": {}, "msg": "Appointment not found."}, status=404)


@api_view(['GET'])
@permission_classes([IsAuthenticated])     
def appointment_new_chats(request, id):
    user_id = request.user.id
    try:
        appoint = Appointment.objects.get(id=id)
        if appoint.patient_id == user_id or appoint.doctor_id == user_id:
            if request.method == 'GET':
                chats = AppointmentChat.objects.filter(appointment_id=appoint.id, seen=False).exclude(msg_by_id=user_id)
                if chats:
                    AppointmentChat.objects.filter(appointment_id=appoint.id, seen=False).exclude(msg_by_id=user_id).update(seen=True)
                return Response({"data": AppointmentChatSerializer(chats, many=True).data, "msg": "Success."})
        else:
            return Response({"data": {}, "msg": "Access Denied."}, status=405)
    except Appointment.DoesNotExist:
        return Response({"data": {}, "msg": "Appointment not found."}, status=404)

