from .health_data_x import HEALTH_DATA_X
from .health_data_y import HEALTH_DATA_Y
# recommendation_model.py
from sklearn.ensemble import RandomForestClassifier
import joblib

def train_model():
    model = RandomForestClassifier()
    model.fit(HEALTH_DATA_X, HEALTH_DATA_Y)
    joblib.dump(model, 'activities/recommendation_model.joblib')

def load_model(filename='activities/recommendation_model.joblib'):
    return joblib.load(filename)

def generate_recommendations(model, health_data):
    # This is a placeholder; replace with your actual logic
    # The model.predict() method should return recommendations based on the input health data
    return model.predict(health_data)


def get_health_data(data: dict):
    return (
        True if data['exercise'] == '1' else False,
        int(data['food_consumption']),
        int(data['water_consumption']),
        True if data['good_sleep'] == '1' else False,
        True if data['smoke'] == '1' else False,
        int(data['stress']),
        int(data['screen_time']),
    )

