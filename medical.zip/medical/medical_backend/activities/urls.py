from django.urls import path
from . import views

urlpatterns = [
    path('my-appointments', views.my_appointments),
    path('my-invoices', views.my_invoices),
    path('doctor-appointments', views.doctor_appointments),
    path('doctor/<str:username>', views.doctor_page_details),
    path('doctor/<int:id>/book-appointment', views.book_appointment),
    path('appointment/<int:id>/feedback', views.appointment_feedback),
    path('appointment/<int:id>/cancel', views.appointment_cancel),
    path('appointment/<int:id>/chats', views.appointment_chats),
    path('appointment/<int:id>/new-chats', views.appointment_new_chats),
]
