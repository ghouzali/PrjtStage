import json
from django.shortcuts import render
from django.http import HttpRequest, JsonResponse
from rest_framework.decorators import api_view
from accounts.models import User, DoctorProfile, UserProfile, SPECIALITIES_DICT, KIND_OF_DISEASES_DICT
from django.contrib.auth import authenticate
from django.db import connection

from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from accounts.serializers import UserSerializer


# Create your views here.
def index(request):
    return JsonResponse({"detail": "Welcome page."})

@api_view(['POST'])
def auth_login(request):
    data = request.data
    user = authenticate(username=data['username'], password=data['password'])
    if user is not None:
        token, _ = Token.objects.get_or_create(user=user)
        return Response({
            "data": {"user": UserSerializer(user).data, "token": token.key},
            "msg": "Logged in successfully."
        }, 201)
    else:
        return Response({"msg": "Username or password are incorrect", "data": {"token": None}}, 200)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def auth_logout(request):
    Token.objects.filter(user=request.user).delete()
    return Response({"msg": "Logged out successfully."}, 200)

@api_view(['POST'])
def user_registration(request):
    data = request.data
    if User.objects.filter(username=data['username']).exists():
        return Response({"msg": "Username already taken.", "data": {"token": None}}, 200)
    else:
        user_role = data['role']
        user = User.objects.create_user(
            first_name=data['first_name'],
            last_name=data['last_name'],
            username=data['username'],
            role=user_role if user_role == 2 else 3,
            gender=data['gender'],
            email=data['email'],
            password=data['password'],
        )
        if user_role == 2:
            DoctorProfile.objects.create(user=user)
        UserProfile.objects.create(user=user)
        token, _ = Token.objects.get_or_create(user=user)
        return Response({
            "data": {"user": UserSerializer(user).data, "token": token.key},
            "msg": "You are registered successfully."
        }, 201)
    
@api_view(['GET'])
def doctor_list(request):
    cond = ""
    if request.GET['search'] != "":
        cond = f"AND (CONCAT(u.first_name, ' ', u.last_name) ILIKE '%{request.GET['search']}%' OR u.username ILIKE '%{request.GET['search']}%')"
    
    # languages = request.GET['languages']

    if request.GET['accept_insurances'] == '1':
        cond += f"AND d.accept_insurances=true"

    if request.GET['specialties']:
        cond += f"AND d.specialty IN ({request.GET['specialties']})"

    if request.GET['gender']:
        cond += f"AND u.gender IN ({request.GET['gender']})"

    if request.GET['kind_of_diseases']:
        cond += f"AND d.kind_of_diseases IN ({request.GET['kind_of_diseases']})"

    if request.GET['languages']:
        cond += f"AND d.language IN ({request.GET['languages']})"

    if request.GET['stars']:
        cond += f"AND FLOOR(stars) IN ({request.GET['stars']})"

    order = ""
    if request.GET['sorting']:
        order = f"ORDER BY {request.GET['sorting']}"

    with connection.cursor() as cursor:
        cursor.execute(
            f"""SELECT u.id, u.first_name, u.last_name, u.username, u.gender, d.avail_days, d.avail_st_time, d.avail_end_time,
            (SELECT SUM(fb.stars) FROM activities_appointmentfeedback fb INNER JOIN activities_appointment ap
            ON fb.appointment_id = ap.id WHERE ap.doctor_id = u.id) / (SELECT COUNT(fb.id) FROM activities_appointmentfeedback fb
            INNER JOIN activities_appointment ap ON fb.appointment_id = ap.id WHERE ap.doctor_id = u.id) as stars,
            d.specialty, d.kind_of_diseases, CONCAT(u.first_name, ' ', u.last_name) AS name
            FROM accounts_user u INNER JOIN accounts_doctorprofile d ON u.id=d.user_id WHERE d.available=true {cond} {order}"""
        )
        rows = cursor.fetchall()
    data = []
    for row in rows:
        data.append({
            "id": row[0], "first_name": row[1], "last_name": row[2],
            "username": row[3], "gender": row[4], "avail_days": json.loads(row[5]),
            "avail_st_time": row[6].strftime("%I:%M %p") if row[6] else None,
            "avail_end_time": row[7].strftime("%I:%M %p") if row[7] else None,
            "stars": round(row[8], 1) if row[8] else None,
            "specialty": SPECIALITIES_DICT.get(row[9], "-"),
            "kind_of_diseases": KIND_OF_DISEASES_DICT.get(row[10], "-") 
        })
    return Response({"data": data, "msg": "Success"})
